

        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyD25YO35Op535NJt4yXCdavMJKIIqKpaEY",
            authDomain: "stamp-app-and-web-application.firebaseapp.com",
            databaseURL: "https://stamp-app-and-web-application-default-rtdb.firebaseio.com",
            projectId: "stamp-app-and-web-application",
            storageBucket: "stamp-app-and-web-application.appspot.com",
            messagingSenderId: "202909813318",
            appId: "1:202909813318:web:7d58f7cb40da06616a1847"
        };

        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        const auth = firebase.auth();
        const firestore = firebase.firestore();

        // Function to add users
        document.getElementById('addUserForm').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const firstName = document.getElementById('firstName').value;
            const lastName = document.getElementById('lastName').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const role = document.getElementById('role').value;

            const password = generatePassword(10);

            // Create user in Firebase Authentication
            auth.createUserWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    const userID = userCredential.user.uid;

                    // Add user details to Firestore
                    return firestore.collection('Users').doc(userID).set({
                        "First Name": firstName,
                        "Last Name": lastName,
                        "Email": email,
                        "Phone Number": phone,
                        "Role": role
                    });
                })
                .then(() => {
                    // Send verification email
                    return auth.currentUser.sendEmailVerification();
                })
                .then(() => {
                    alert(`User added successfully! Email verification sent to ${email}.`);
                    sendEmail(email, password, firstName, lastName, role);
                    document.getElementById('addUserForm').reset();
                })
                .catch((error) => {
                    console.error("Error adding user: ", error);
                    alert(`Error adding user: ${error.message}`);
                });
        });

        // Helper function to generate random password
        function generatePassword(length) {
            const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
            let password = "";
            for (let i = 0; i < length; i++) {
                password += charset.charAt(Math.floor(Math.random() * charset.length));
            }
            return password;
        }

        // Function to send email with login details using EmailJS
        function sendEmail(email, password, firstName, lastName, role) {
            const templateParams = {
                to_email: email,
                to_name: `${firstName} ${lastName}`,
                role: role,
                email: email,
                password: password
            };

            return emailjs.send('service_i1vchup', 'template_4csealy', templateParams)
                .then((response) => {
                    console.log('Email sent successfully:', response.status, response.text);
                })
                .catch((error) => {
                    console.error('Error sending email:', error);
                    throw error; 
                });
        }
    
        1   

         