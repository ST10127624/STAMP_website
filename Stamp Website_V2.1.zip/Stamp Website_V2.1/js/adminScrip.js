    

                // Firebase configuration
                const firebaseConfig = {
                    apiKey: "AIzaSyD25YO35Op535NJt4yXCdavMJKIIqKpaEY",
                    authDomain: "stamp-app-and-web-application.firebaseapp.com",
                    databaseURL: "https://stamp-app-and-web-application-default-rtdb.firebaseio.com",
                    projectId: "stamp-app-and-web-application",
                    storageBucket: "stamp-app-and-web-application.appspot.com",
                    messagingSenderId: "202909813318",
                    appId: "1:202909813318:web:7d58f7cb40da06616a1847"
                };
            
                // Initialize Firebase
                firebase.initializeApp(firebaseConfig);
                const auth = firebase.auth();
                const firestore = firebase.firestore();
            
                // Check if user is logged in
                auth.onAuthStateChanged((user) => {
                    if (user) {
                        // User is signed in
                        firestore.collection('Users').doc(user.uid).get()
                            .then((doc) => {
                                if (doc.exists) {
                                    const userData = doc.data();
                                    document.getElementById('userGreeting').textContent = `Hello, ${userData['First Name']}!`;
                                    
                                    // Check if user is an admin
                                    if (userData.Role !== 'Admin') {
                                        // If not an admin, redirect to login page
                                        alert('You do not have permission to access this page.');
                                        window.location.href = 'account_Login.html';
                                    }
                                    else if (role !== 'Marshal') {
                                        window.location.href = 'account_Login.html';
                                    } 
                                    else if (role !== 'Passenger') {
                                        window.location.href = 'account_Login.html';
                                    }
                                } else {
                                    console.log("No such document!");
                                }
                            }).catch((error) => {
                                console.log("Error getting document:", error);
                            });
                    } else {
                        // No user is signed in, redirect to login page
                        window.location.href = 'account_Login.html';
                    }
                });
            
                // Logout functionality
                document.getElementById('logoutButton').addEventListener('click', () => {
                    auth.signOut().then(() => {
                        // Sign-out successful.
                        window.location.href = 'account_Login.html';
                    }).catch((error) => {
                        // An error happened.
                        console.error("Logout error:", error);
                    });
                });