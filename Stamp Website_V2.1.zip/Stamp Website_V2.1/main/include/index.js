
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyD25YO35Op535NJt4yXCdavMJKIIqKpaEY",
    authDomain: "stamp-app-and-web-application.firebaseapp.com",
    databaseURL: "https://stamp-app-and-web-application-default-rtdb.firebaseio.com",
    projectId: "stamp-app-and-web-application",
    storageBucket: "stamp-app-and-web-application.appspot.com",
    messagingSenderId: "202909813318",
    appId: "1:202909813318:web:7d58f7cb40da06616a1847"
  };

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

//reference database
var StampWebapp = firebase.database().ref('addMarshall_form');

document.getElementById('addMarshall_form').addEventListener('submit', submitForm )

function submitForm(e){
    e.preventDefault();

    var firstname = getElementVal('firstname');
    var lastname = getElementVal('lastname');
    var associationname = getElementVal('associationname');
    var phonenumber = getElementVal('phoneNumber')
    var email = getElementVal('email');
    var password = getElementVal('password');
    //calling function
    SaveMarshall(firstname, lastname, associationname,phonenumber, email, password);
    //   enable alert
  document.querySelector(".alert").style.display = "block";
  //   remove the alert
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 31000);

   //   reset the form
   document.getElementById("addMarshall_form").reset();
  
}
//saving to the database
const SaveMarshall = (firstname, lastname, associationname,phonenumber, email, password) => {
    var newMarshall = StampWebapp.push();
  
    newMarshall.set({
        firstname : firstname,
        lastname :lastname,
        associationname :associationname,
        phonenumber : phonenumber,
        email : email,
        password : password,
    });
  };



const getElementVal = (id) => {
    return document.getElementById(id).value;
  };